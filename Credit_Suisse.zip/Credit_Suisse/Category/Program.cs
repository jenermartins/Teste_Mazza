﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using Category.Entity;
using Category.Facade;
using Category.Service;


namespace Credit_Suisse
{
    public class Program
    {
        public static void Main()
        {
            try
            {
                
                Console.WriteLine("Iniciando processo");

                IList<iNegocio> lst_Negocios = new List<iNegocio>();
                iRisco risco_negocio = new Risco();

                lst_Negocios.Add(new Negocio { Valor = 2000000, Setor_Cliente = "Privado" });
                lst_Negocios.Add(new Negocio { Valor = 400000, Setor_Cliente = "Publico" });
                lst_Negocios.Add(new Negocio { Valor = 500000, Setor_Cliente = "Publico" });
                lst_Negocios.Add(new Negocio { Valor = 3000000, Setor_Cliente = "Publico" });

                var lst_risco = risco_negocio.getRisco_Negocio((IList<Negocio>)lst_Negocios);

                foreach(var riscos in lst_risco)
                {
                    Console.WriteLine(riscos);
                }

                Console.WriteLine("Processo finalizado");

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}