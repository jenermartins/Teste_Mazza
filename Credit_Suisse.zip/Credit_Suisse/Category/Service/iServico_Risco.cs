﻿using System;
using System.Diagnostics;
using Category.Entity;

namespace Category.Service
{
    public interface iServico_Risco
    {
        IList<string> getRisco_Negocio(IList<iNegocio> negocios);
    }
}
