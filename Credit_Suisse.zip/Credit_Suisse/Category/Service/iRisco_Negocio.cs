﻿using System;

namespace Category.Service
{
    public interface iRisco_Negocio
    {
        string getRisco(double Valor, double Limite_Risco);
    }
}

