﻿using System;
using System.Diagnostics;
using Category.Entity;

namespace Category.Facade
{
    public interface iRisco
    {
        IList<string> getRisco_Negocio(IList<Negocio> negocios);
    }
}