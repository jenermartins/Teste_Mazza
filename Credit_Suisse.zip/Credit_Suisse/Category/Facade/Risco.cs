﻿using System;
using System.Diagnostics;
using Category.Service;
using Category.Entity;
using Category.Service;

namespace Category.Facade
{
    public class Risco : iRisco
    {
        private readonly iServico_Risco servico_risco;

        public Risco()
        {
            Servico_Risco servico_risco = new Servico_Risco();
        }

        public IList<string> getRisco_Negocio(IList<Negocio> negocios)
        {
            var listaRisco_Negocio = servico_risco.getRisco_Negocio((IList<iNegocio>)negocios);
            return listaRisco_Negocio;
        }

        public object getRisco_Negocio(IList<iNegocio> trades)
        {
            throw new NotImplementedException();
        }
    }
}