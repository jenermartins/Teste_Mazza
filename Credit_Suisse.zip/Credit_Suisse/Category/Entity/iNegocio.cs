﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Category.Entity
{
    public interface iNegocio
    {
        double Valor { get; }
        string Setor_Cliente { get; }
    }
}