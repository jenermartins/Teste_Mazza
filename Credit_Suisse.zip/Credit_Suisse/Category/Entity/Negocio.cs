﻿using System;
using System.Diagnostics;
using Category.Entity;

namespace Category.Entity
{
    public class Negocio : iNegocio
    {
        public double Valor { get; set; }
        public string Setor_Cliente { get; set; }
    }
}